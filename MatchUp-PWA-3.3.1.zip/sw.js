'use strict';
const CACHE = 'matchup-static-cce2b5a8ab1db45f1edb';
const FILES = ["index.html","mentorship.js","mentorship.css","mentorship-academic.js","mentorship-academic.css","mentorship-catalog.js","mentorship-catalog.css","mentorship-product.js","mentorship-calendar.js","vendor/supabase.js","pwa.js","pwa.css","manifest.webmanifest","assets/brand/matchup-symbol.png","assets/brand/matchup-logo.png","assets/brand/icon-192.png","assets/brand/icon-512.png","assets/brand/icon-maskable-512.png","assets/brand/apple-touch-icon.png","assets/brand/favicon-32.png"];
const urls = FILES.map(file => new URL(file, self.registration.scope).href);
const allowed = new Set(urls);
const shell = new URL('index.html', self.registration.scope).href;
const home = new URL('./', self.registration.scope).pathname;

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(urls.map(url => new Request(url, {cache:'reload', credentials:'omit'})))));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('matchup-static-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('message', event => {
  if (event.data?.type === 'MATCHUP_ACTIVATE_UPDATE') self.skipWaiting();
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || request.headers.has('authorization')) return;
  // Navigation queries may contain recovery tokens. Never store the response or URL.
  if (request.mode === 'navigate' && (url.pathname === home || url.pathname === new URL(shell).pathname)) {
    // Static hosts may redirect index.html; navigation fallback needs a non-redirected response.
    event.respondWith(fetch(request).catch(() => caches.open(CACHE).then(cache => cache.match(shell)).then(cached => cached && new Response(cached.body, {status:cached.status, statusText:cached.statusText, headers:cached.headers}))));
    return;
  }
  // Only the explicit, public application shell is cached, never API or user data.
  if (url.search || !allowed.has(url.href)) return;
  event.respondWith(caches.open(CACHE).then(cache => cache.match(url.href)).then(cached => cached || fetch(request)));
});
